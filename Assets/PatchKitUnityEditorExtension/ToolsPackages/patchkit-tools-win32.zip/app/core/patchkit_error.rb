module PatchKitTools
  class CommandLineError < StandardError
  end
  class APIJobError < StandardError
  end
  class APIPublishError < StandardError
  end
end
