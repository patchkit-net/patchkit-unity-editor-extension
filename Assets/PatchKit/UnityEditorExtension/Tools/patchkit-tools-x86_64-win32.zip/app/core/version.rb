module PatchKitTools
  VERSION = '3.1.7'.freeze
end
