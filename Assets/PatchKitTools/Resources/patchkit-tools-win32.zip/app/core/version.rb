module PatchKitTools
  VERSION = '2.4.0'.freeze
end
